﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

//Author: Darshitkumar Patel
//Description: EMail checker
//Use: Regular Expression

namespace email_helper___500_pts_meghdeep14
{
    class Program
    {
        public static void GetEmailName()
        {
            string email, name, fEmail;

            
            email = "@conestogac.on.ca";
            name = "darshit";

            fEmail = name + email;

            Console.WriteLine(fEmail);

            Regex regex1 = new Regex("^[a-zA-Z]+[a-zA-Z0-9]+[[a-zA-Z0-9-_.!#$%'*+/=?^]{1,20}@conestogac.on.ca");
            
            if (regex1.IsMatch(fEmail))
                {
                   Console.WriteLine("true");
                }
                else
                {
                   Console.WriteLine("false");
                }                                 
        }
        static void Main(string[] args)
        {
            GetEmailName();
        }
    }
}
