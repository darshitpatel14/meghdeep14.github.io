﻿using System;

namespace Helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            String FirstName, LastName, Address, City, Instru, Number, Order, Item;
            Double Pizza, Price, O1, Total, Dis, Stotal, Tax, Ftotal;


            bool ValidChoiceChk, ValidChoiceChk1;

            Console.WriteLine("\t\t\tArnold's Amazing Eats");
            Console.WriteLine("the best food in Waterloo and delivers it to your home.");
            Console.WriteLine("Only Pizza is deliverd at this time!");

            Console.Write("\nEnter your Firstname: ");
            FirstName = Console.ReadLine();

            Console.Write("Enter Your Lastname: ");
            LastName = Console.ReadLine();

            Console.Write("Enter your delivery address in the form of street number, street name, unit: ");
            Address = Console.ReadLine();

            Console.Write("Enter your city, province, postal code: ");
            City = Console.ReadLine();

            Console.Write("Enter your special instruction: ");
            Instru = Console.ReadLine();

            Console.Write("Enter your phone number: ");
            Number = Console.ReadLine();

            Pizza = 12.75;

            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Pizza");

            Console.Write("\nType Pizza if ypu want to order: ");
            Item = Console.ReadLine();

            Console.Write("How much: ");
            Order = Console.ReadLine();
            O1 = Double.Parse(Order);

            Console.WriteLine("\nYour order is " + Order + " amount of " + Item);

            do
            {
                String ConfirmPrompt;
                Console.Write("If this is correct type Y eles N: ");
                ConfirmPrompt = Console.ReadLine();

                ValidChoiceChk = (ConfirmPrompt.ToUpper() == "Y");

                if (ValidChoiceChk == true)
                    Console.WriteLine("your order is Confirm");
                else
                {
                    Console.WriteLine("You have not confirm your order yet");
                    do
                    {
                        Console.WriteLine("Menu:");
                        Console.WriteLine("1. Pizza");

                        Console.Write("\nType Pizza if you want to order: ");
                        Item = Console.ReadLine();

                        Console.WriteLine("How much: ");
                        Order = Console.ReadLine();
                        O1 = Double.Parse(Order);
                        Console.WriteLine("Your order is " + Order + " amount of " + Item);

                    } while (ValidChoiceChk == true);
                }



            } while (!ValidChoiceChk);


            String ConfirmPrompt1;
            Console.Write("Are you a Student [Y/N]:");
            ConfirmPrompt1 = Console.ReadLine();

            ValidChoiceChk1 = (ConfirmPrompt1.ToUpper() == "Y");

            if (ValidChoiceChk1 == true)
                Console.WriteLine("You will get 10% Discount");


            Price = Pizza;
            Total = Price * O1;


            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Blue;

            Console.WriteLine("\n \t\t\tReceipt");
            Console.WriteLine("\t\tPersonal Information");
            Console.WriteLine("Name: " + FirstName + " " + LastName);
            Console.WriteLine("Address: " + Address);
            Console.WriteLine("City: " + City);
            Console.WriteLine("Instruction: " + Instru);

            Console.WriteLine("\n \t\t\tPayment Receipt");
            Console.WriteLine("\n Order\t\tItem Amount \tItem Price \tTotal");
            Console.WriteLine("_________ \t___________\t__________ \t______");
            Console.WriteLine("  " + Item + "\t\t    " + Order + " \t\t  " + "$" + Price + " \t" + "$" + Total);

            Dis = Total / 10;


            if (ValidChoiceChk1 == true)
            {
                Console.WriteLine("10% Student Saving" + "\t\t\t\t" + "-$" + Dis);
            }

            Stotal = Total - Dis;
            Tax = (Stotal * 13) / 100;
            Ftotal = Stotal + Tax;

            Console.WriteLine("\n\t\t\t\tSub Total\t" + "$" + Stotal);
            Console.WriteLine("\t\t\t\tTax(13%)\t" + "$" + Tax);
            Console.WriteLine("\t\t\t\t\t\t__________");
            Console.WriteLine("\t\t\t\tTotal\t\t" + "$" + Ftotal);








        }
    }
}