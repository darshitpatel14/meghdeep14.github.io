﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

//Author: Darshitkumar Patel
//Description: EMail checker
//Use: Regular Expression

namespace conestoga_email_checker_3500_pts_meghdeep14
{
    class Program
    {
        public static void CCEmailChecker()
        {
            string email;
            
            email = "dpatel9917@conestogac.on.ca";

            Regex regex1 = new Regex("^[a-zA-Z]+[a-zA-Z0-9]+[[a-zA-Z0-9-_.!#$%'*+/=?^]{1,20}@conestogac.on.ca");
            
            if (regex1.IsMatch(email))
                {
                   Console.WriteLine("true");
                }
                else
                {
                   Console.WriteLine("false");
                }                                 
        }
        static void Main(string[] args)
        {
            CCEmailChecker();
        }
    }
}
