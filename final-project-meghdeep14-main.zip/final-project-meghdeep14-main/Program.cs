﻿using System;

//Author: Darshitkumar Patel
//Description: Using controlling program flow, string, methods, 
//             switch statement, string methods, Randomness, etc. topics,
//             which i studied in this semester, using that i code this game.
//Game reference : Machine of death by Hulk Handsom

namespace final_project_meghdeep14
{
    class Program
    {
        //First method 
        //for gam title
        public static void title()     
        {
            //Use of randomness
            int chosenRandom;
            Random randValue = new Random();

            //MD is shortname of my nickname (MEGHDEEP)            
            Console.WriteLine("----      ---- --------------");
            Console.WriteLine("-- --    -- --  --------------");
            Console.WriteLine("--  --  --  --  --          --"); 
            Console.WriteLine("--   ----   --  --          --");
            Console.WriteLine("--          --  --          --");
            Console.WriteLine("--          --  --          --");
            Console.WriteLine("--          --  --------------");
            Console.WriteLine("--          -- --------------"); 
            Console.WriteLine("Welcome to my world!");
            Console.WriteLine("  ");

            //To give player number i choose random method.
            chosenRandom = randValue.Next(9999);
            Console.WriteLine("Player Number: " + chosenRandom);
            Console.WriteLine("press Enter to begin.");
            Console.ReadLine();
            game();
            Console.Clear();
        }

        //Second method
        //For firstpage of the game
        public static void game()
        {
            string choice, order, lSand, sSand, uCatch, post, match;
            
            Console.WriteLine("You enter in the sigma mall");
            Console.WriteLine("To your left is a fast food restaurant.");
            Console.WriteLine("To the right is a UFO catcher, and a poster is hanging on the wall beside it.");
            Console.WriteLine("Behind you is the one of the mall's exits.");
            Console.WriteLine("In front of you stands the Machine.");
            Console.WriteLine("");
            Console.WriteLine("If you don't want to go at any other location of the mall then press 5 for use machine");
            Console.WriteLine("");
            Console.WriteLine("1. Fast food restaurant");
            Console.WriteLine("2. UFO catcher");
            Console.WriteLine("3. Poster");
            Console.WriteLine("4. Mall");
            Console.WriteLine("5. The Machine.");
            Console.WriteLine("  ");
            Console.Write("Enter your choice: ");
            choice = Console.ReadLine();
            Console.Clear();

            //Switch statement
            switch (choice)
            {
                case "1":
                {
                    Console.WriteLine("take a look at menu...");
                    Console.WriteLine("  ");
                    Console.WriteLine("1. A Lister sandwitch");
                    Console.WriteLine("2. A pie floater");
                    Console.WriteLine("3. A sinner's sandwitch");
                    Console.WriteLine("  ");
                    Console.WriteLine("Enter your order number: ");
                    order = Console.ReadLine();
                    Console.Clear();
                   
                    switch (order)
                    {
                        case "1":
                        {
                            Console.WriteLine("The Lister sandwich");
                            Console.WriteLine("  ");
                            Console.WriteLine("1. Buy one for two dollars.");
                            Console.WriteLine("Press 1 for buy it or press 0 for return to the mall.");
                            Console.WriteLine("  ");
                            Console.Write("Your choice: ");
                            lSand = Console.ReadLine();
                            int lSand1 = int.Parse(lSand);
                            Console.Clear();

                            if (lSand1 == 1)
                            {
                                Console.WriteLine("The trick to a Lister Sandwich is to eat it before the bread disintegrates.");
                                Console.WriteLine("It makes you feel like you're having a baby.");
                                Console.WriteLine("  ");
                                Console.WriteLine("\nPress Enter to return your eyes on the mall");
                                Console.ReadLine();
                                game();
                            }
                            else 
                            {
                                game();
                            }  
                        break;
                        } 
                        case "2":
                        {
                            Console.WriteLine("A Pie Floater. An inverted meat pie floating in mushy pea soup, drenched with tomato sauce.");
                            Console.WriteLine("These are traditionally sold in vans on the streets of Australian cities,");
                            Console.WriteLine("recommended to be eaten whilst standing, and also very, very drunk.");
                            Console.WriteLine("Tragically (or perhaps luckily), you're not carrying enough money to experience this culinary curiosity.");
                            Console.WriteLine("  ");
                            Console.WriteLine("press Enter to return your eyes on the mall");
                            Console.ReadLine();
                            game();
                            Console.Clear();
                        }  
                        break;
                        case "3":
                        {
                            Console.WriteLine("The Sinner's Sandwich. Freshly shaved slices of turkey, strawberry jam,");
                            Console.WriteLine("and a sprinkling of honey nut cornflakes between two slices of bread.");
                            Console.WriteLine("  ");
                            Console.WriteLine("1. Buy one for two dollars.");
                            Console.WriteLine("  ");
                            Console.WriteLine("Press 1 for buy it or press 0 for return to the mall.");
                            Console.WriteLine("  ");
                            Console.Write("Your choice: ");
                            sSand = Console.ReadLine();
                            int sSand1 = int.Parse(sSand);
                            Console.Clear();

                            if (sSand1 == 1)
                            {
                                Console.WriteLine("The trick to a Lister Sandwich is to eat it before the bread disintegrates.");
                                Console.WriteLine("It makes you feel like you're having a baby.");
                                Console.WriteLine("  ");
                                Console.WriteLine("\nPress Enter to return your eyes on the mall");
                                Console.ReadLine();
                                game();
                            }
                            else 
                            {
                                game();
                            }  
                            Console.ReadLine();
                            game();
                        }  
                        break;
                    }
                    gameOver();
                    break;
                }
                case "2":
                {
                    Console.WriteLine("You wander over to the UFO catcher and peek at what's trapped behind the glass.");
                    Console.WriteLine("There doesn't seem to be anything too excit...");
                    Console.WriteLine("holy hell! There's a Wee Rex Adorable Plush in there! It looks delightfully cuddly in all its green glory.");
                    Console.WriteLine("  ");
                    Console.WriteLine("1. Jam in a coin and try to win that baby!");
                    Console.WriteLine("0. Return your eyes to the mall.");
                    Console.WriteLine("  ");
                    Console.Write("Enter your choice: ");
                    uCatch = Console.ReadLine();
                    int uCatch1 = int.Parse(uCatch);
                    Console.Clear();

                    if (uCatch1 == 1)
                    {
                        Console.WriteLine("You manoeuvre the crane over the tiny dino, lower and clasp the jaws around it, and lift it back up...");
                        Console.WriteLine("only for it to fall from the crane's frustratingly weak grasp. Curses! Foiled again, like yesterday's ham!");
                        Console.WriteLine("  ");
                        Console.WriteLine("Sadly, you don't have any change left to try to win the dazzling dinosaur again.");
                        Console.WriteLine("  ");
                        Console.WriteLine("Press Enter to return your eyes on the mall");
                        Console.ReadLine();
                        game();
                    }
                    else 
                    {
                        game();
                    }  

                    gameOver();
                    break;
                }
                case "3":
                {
                    Console.WriteLine("The poster is advertising the upcoming tour of stand-up comedian Phil Bison, also known as the Cancer Comic.");
                    Console.WriteLine("  ");
                    Console.WriteLine("\nPress Enter to return your eyes on the mall");
                    Console.ReadLine();
                    game();
                    break;
                }
                case "4":
                {
                    Console.WriteLine("You turn around and look at the two sliding doors leading to the outside world.");
                    Console.WriteLine("  ");
                    Console.WriteLine("\n1. You decide to leave");
                    Console.WriteLine("2. You decide to stay and turn back around.");
                    Console.WriteLine("  ");
                    Console.Write("Enter your choice: ");
                    post = Console.ReadLine();
                    int post1 = int.Parse(post);
                    Console.Clear();

                    if (post1 == 1)
                    {
                        gameOver();
                    }
                    else if (post1 == 2)
                    {
                        game();
                    }
                    game();
                    break;
                }
                case "5":
                {
                    Console.WriteLine("Here's how it works: a person inserts a dollar and sticks their finger in the machine, which takes a blood sample.");
                    Console.WriteLine("A little card is then spat out, which reveals the person's final fate.;");
                    Console.WriteLine("  ");
                    Console.WriteLine("Events like this have led some to believe that the Machine has a sense of humour.");
                    Console.WriteLine("  ");
                    Console.WriteLine("You never did get yourself tested.");
                    Console.WriteLine("  ");
                    Console.WriteLine("Maybe today is the day.");
                    Console.WriteLine("  ");
                    Console.WriteLine("1. Insert a coin");
                    Console.WriteLine("2. Stand back and watch people use the Machine.");
                    Console.WriteLine("  ");
                    Console.Write("Enter your choice: ");
                    match = Console.ReadLine();
                    int match1 = int.Parse(match);
                    Console.Clear();

                    if (match1 == 1)
                    {
                        second();
                    }
                    else if (match1 == 2)
                    {
                        third();
                    }
                    game();
                    break;
                }
                default:
                {
                    Console.WriteLine("Invalid Choice");
                    Console.WriteLine("  ");
                    Console.WriteLine("press Enter to try again");
                    Console.ReadLine();
                    game();
                    break;
                }
            }
        }

        //Third method
        //For use a machin
        public static void second()
        {
  
            string slam, choice1, car, help, choiceChk;

            Console.WriteLine("OLD AGE");
            Console.WriteLine("When you go out for driving during the snow and suddenly a deer appears in your headlights..");
            Console.WriteLine("  ");
            Console.WriteLine("1. Slam on your brakes!");
            Console.WriteLine("2. Screw the deer! keep on driving!");
            Console.WriteLine("  ");
            Console.Write("Enter your choice: ");
            slam = Console.ReadLine();
            int slam1 = int.Parse(slam);
            Console.Clear();
            
            if (slam1 == 1)
            {
                Console.WriteLine("You slam on the breaks, sending your car spinning off the icy roads and straight into a mound of snow with a mighty VOOMPF!");
                Console.WriteLine("Well, this is a rather unfortunate situation.");
                Console.WriteLine("Not life threatening - at least, not to you - but tedious nonetheless.");
                Console.WriteLine(" Still, better try find a way out of this predicament.");
                Console.WriteLine("  ");
                Console.WriteLine("1. Try starting the car.");
                Console.WriteLine("2. Get out of car.");
                Console.WriteLine("  ");
                Console.Write("Enter your choice: ");
                choice1 = Console.ReadLine();

                switch (choice1)
                {
                    case "1":
                    {
                        Console.WriteLine("You push the airbag out of the way and see if the car will start.");
                        Console.WriteLine("  ");
                        Console.WriteLine("1. Try starting the car again.");
                        Console.WriteLine("2. Go outside.");
                        Console.WriteLine("  ");
                        Console.Write("Enter your choice: ");
                        car = Console.ReadLine();
                        int car1 = int.Parse(car);
                        Console.Clear();

                        if (car1 == 1)
                        {
                            Console.WriteLine("You try the ignition again to see if the car has suddenly decided that it wants to start.");
                            Console.WriteLine("  ");
                            Console.WriteLine("And It's start");
                            Console.WriteLine("  ");
                            Console.WriteLine("THE END");
                            gameOver();
                        }
                        else
                        {
                            Console.WriteLine("You bundle yourself up as much as you can and step out of the car.");
                            Console.WriteLine("As suspected, it is cold. Very cold. Snow storms around you.");
                            Console.WriteLine("  ");
                            Console.WriteLine("press Enter to Go in search of help.");
                            Console.ReadLine();
                            youWin();
                        }
                    break;
                    }
                    case "2":
                    {
                        Console.WriteLine("You bundle yourself up as much as you can and step out of the car.");
                        Console.WriteLine("As suspected, it is cold. Very cold. Snow storms around you.");
                        Console.WriteLine("  ");
                        Console.WriteLine("1. Get back in the car.");
                        Console.WriteLine("2. Go in search of help.");
                        Console.WriteLine("  ");
                        Console.Write("Enter your choice: ");
                        help = Console.ReadLine();
                        int help1 = int.Parse(help);
                        Console.Clear();

                        if (help1 == 1)
                        {
                            Console.WriteLine("You try the ignition again to see if the car has suddenly decided that it wants to start.");
                            Console.WriteLine("  ");
                            Console.WriteLine("And It's start");
                            Console.WriteLine("THE END");
                            gameOver();
                        }
                        else
                        {
                            Console.WriteLine("  ");
                            Console.Write("Do you think about to help that deer.[y/n]: ");
                            choiceChk = Console.ReadLine();
                            {
                                //choice check 
                                if ((choiceChk == "Y") || (choiceChk == "y"))
                                {
                                    youWin();
                                }
                                else if(choiceChk == "N" || choiceChk =="n")
                                {
                                    gameOver();
                                }
                                else
                                {
                                    //If player press any other key than...
                                    Console.WriteLine("Invalid Choice...");
                                    Console.WriteLine("  ");
                                    Console.WriteLine("press Enter to start again.");
                                    Console.ReadLine();
                                    second();
                                }
                            }
                                 
                        }
                    break;    
                    }

                }

            }
            else
            {
                gameOver();
            }            
        }

        //Fourth method
        //For see how to use machine
        public static void third()
        {
            string death;

            Console.WriteLine("You stand back and watch others approach the Machine.");
            Console.WriteLine("A male who looks to be in his mid-to-late twenties walks towards it, shaking.");
            Console.WriteLine("  ");
            Console.WriteLine("He inserts a coin, has his finger jabbed,");
            Console.WriteLine(" and picks up the ticket that's printed shortly afterwards. With reluctance,");
            Console.WriteLine("he reads it and a wave of relief rolls across his body. He wipes sweat from his brow and walks away,");
            Console.WriteLine(" still a little shaken, but not stirred.");
            Console.WriteLine("  ");
            Console.WriteLine("Doing a bit of deathspotting, huh?");
            Console.WriteLine("  ");
            Console.Write("Deathspotting? [Yeah/Nah]: ");
            death = Console.ReadLine();
            Console.Clear();

            //Trim whitespace and capitalize what player write
            if (death.ToUpper().Trim() == "YEAH")
            {
                second();
            }
            else if (death.ToUpper().Trim() == "NAH")
            {
                gameOver();
            }
            else
            {
                //If answer is other than yeah or nah, than...
                Console.WriteLine("Invalid choice...");
                Console.WriteLine("  ");
                Console.WriteLine("Press Enter to play game again.");
                Console.ReadLine();
                game();
            }
        }

        //Fifth method
        //For end of the game
        public static void gameOver()
        {
            Console.WriteLine("THE END");
            Console.WriteLine("  ");
            Console.WriteLine("better luck next tym");
            Console.WriteLine("  ");
            Console.WriteLine("press enter to play again");
            Console.ReadLine();
            title();
        }

        //Sixth method
        //For winning the game
        public static void youWin()
        {
            Console.WriteLine("Great Job! You won!");
            Console.WriteLine("  ");
            Console.WriteLine("press enter to play again");
            Console.ReadLine();
            title();
        }

        //Main method
        static void Main(string[] args)
        {
            title();
            game();
        }
    }
}
