﻿using System;
using System.IO;

//Assignment 3
//author : Darshitkumar Patel
//Title : Arnold's Amazing Eats
//Use : Structure, Loop, Array, Methods

namespace assignment_3_meghdeep14
{
    //Use of structure for username
    struct FullName
    {
        public string firstName;
        public string lastName;
    }

    //Use of structure for user address
    struct FullAddress
    {
        public string address;
        public string city;
        public string province;
        public string pCode;
    }
    
    //Use of structure for extra information of user.
    struct Extra
    {
        public string instruction;
        public string number;
        public string order;
        public string item;
        public string confirmPrompt2;
        public string confirmPrompt3;
        public string tip;
        public double tip1;
        public double tip2;
    }

    class Program
    {
        private static Random randValue = new Random();
        static void Main(string[] args)
        {
            FullName name;
            FullAddress add;
            Extra info;
            double o1, total, dis, sTotal, tax, fTotal, item1;
            bool validChoiceChk, validChoiceChk1, validChoiceChk2, validChoiceChk3;
            int ChosenRandom;

            //Main title and description
            Console.WriteLine("\t\t\tArnold's Amazing Eats");
            Console.WriteLine("the best food in Waterloo and delivers it to your home.");
            Console.WriteLine("Only Pizza is delivered at this time!");

            //Get user information
            Console.Write("\nEnter your Firstname: ");
            name.firstName = Console.ReadLine();

            Console.Write("Enter Your Lastname: ");
            name.lastName = Console.ReadLine();

            Console.Write("Enter your delivery address in the form of street number, street name, unit: ");
            add.address = Console.ReadLine();

            Console.Write("Enter your city name: ");
            add.city = Console.ReadLine();

            Console.Write("Enter your province name: ");
            add.province = Console.ReadLine();

            Console.Write("Enter your postal code: ");
            add.pCode = Console.ReadLine();

            //If the User selects the delivery option, then the program asks for a tip...
            Console.Write("Delivery [Y/N]: ");
            info.confirmPrompt2 = Console.ReadLine();
            validChoiceChk2 = (info.confirmPrompt2.ToUpper() == "Y");
            if (validChoiceChk2 == true)
            {
                Console.Write("Have you want to give a tip to the delivery man [Y/N]:");
                info.confirmPrompt3 = Console.ReadLine();
                validChoiceChk3 = (info.confirmPrompt3.ToUpper() == "Y");
                if (validChoiceChk3 == true)
                {
                    Console.Write("How much(10%, 15%, 20%):");
                    info.tip = Console.ReadLine();
                    info.tip1 = Double.Parse(info.tip);
                }
            }

            Console.Write("Enter your special instruction: ");
            info.instruction = Console.ReadLine();

            Console.Write("Enter your phone number: ");
            info.number = Console.ReadLine();

            //Menu and quantity of an item
            //If User writes word for choose order, then it gives an error.
            //User must write a number for choose item.
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Pizza : 12.75");

            Console.Write("\nChoose number from menu to order: ");
            info.item = Console.ReadLine();
            
            //Exception Handling
            try
            {
                item1 = Double.Parse(info.item);
            }
            catch
            {
                Console.WriteLine("Invalid Number");
            }

            Console.Write("How much: ");
            info.order = Console.ReadLine();
            o1 = Double.Parse(info.order);
          
            Console.WriteLine("\nYour order is " + info.order + " amount of Pizza.");

            //Use of loop
            //If the user does not confirm the order, then it shows Menu again.
            do
            {
                String confirmPrompt;
                Console.Write("If this is correct type Y else N: ");
                confirmPrompt = Console.ReadLine();

                validChoiceChk = (confirmPrompt.ToUpper() == "Y");

                if (validChoiceChk == true)
                    Console.WriteLine("your order is Confirm");
                else
                {
                    Console.WriteLine("You have not confirm your order yet");
                    do
                    {
                        Console.WriteLine("Menu:");
                        Console.WriteLine("1. Pizza : 12.75");

                        Console.Write("\nChoose number from menu to order: ");
                        info.item = Console.ReadLine();

                        Console.WriteLine("How much: ");
                        info.order = Console.ReadLine();
                        o1 = Double.Parse(info.order);
                        Console.WriteLine("Your order is " + info.order + " amount of " + info.item);

                    } while (validChoiceChk == true);
                }

            } while (!validChoiceChk);

            //Discount for students
            String confirmPrompt1;
            Console.Write("Are you a Student [Y/N]:");
            confirmPrompt1 = Console.ReadLine();

            validChoiceChk1 = (confirmPrompt1.ToUpper() == "Y");

            if (validChoiceChk1 == true)
                Console.WriteLine("You will get 10% Discount");

            total = 12.75 * o1;

            //Final Receipt with Background and foreground color.
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.Blue;

            //File Handling
            StreamWriter writer;
            String path;

            path = @"C:\Users\darsh\OneDrive\Documents\Assignment 3\assignment-3-meghdeep14\Receipt.txt";
            writer = new StreamWriter(path, true);

            Console.WriteLine("\n \t\t\tReceipt");
            Console.WriteLine("\t\tPersonal Information");
            Console.WriteLine("Name: " + name.firstName + " " + name.lastName);
            Console.WriteLine("Address: " + add.address + ", " + add.city + ", " + add.province + ", " + add.pCode);

            Console.WriteLine("Instruction: " + info.instruction);

            //If User selects delivery option then it prints on receipt
            //Otherwise, it is not shown.
            if (validChoiceChk2 == true)
            {
                Console.WriteLine("Mode: Delivery");
            }

            //Free discount code for 8% customers
            Console.WriteLine("\n Congratulation");
            Console.WriteLine("You are selected for getting discount");
            Console.Write("Free Discount Code:");
            ChosenRandom = randValue.Next(11);

            ChosenRandom = randValue.Next(1000000000,1111111111);
            Console.WriteLine(ChosenRandom);


            Console.WriteLine("\n \t\t\tPayment Receipt");
            Console.WriteLine("\n Order\t\tItem Amount \tItem Price \tTotal");
            Console.WriteLine("_________ \t___________\t__________ \t______");
            Console.WriteLine("  " + "Pizza" + "\t\t    " + info.order + " \t\t  " 
                + "$" + 12.75 + " \t" + "$" + "{0:0.00}", total);

            //If user is student, then 10% discount will be given.
            dis = total / 10;

            if (validChoiceChk1 == true)
            {
                Console.WriteLine("10% Student Saving" + "\t\t\t\t" + "-$" + "{0:0.00}", dis);
            }

            Console.WriteLine("Discount of Code " + ChosenRandom + "\t\t\t-$5.00" );

            sTotal = total - dis - 5;
            tax = (sTotal * 13) / 100;
            info.tip2 = (sTotal * 10) / 100;

            Console.WriteLine("\n\t\t\t\tSub Total\t" + "$" + "{0:0.00}", sTotal);
            Console.WriteLine("\t\t\t\tTax(13%)\t" + "$" + "{0:0.00}", tax);

            //If the delivery option is selected and the subtotal of the order is below $30.
            //Then $5 is added in total as a delivery charge.
            // Delivery charge is waived for subtotal over $30.
            if (validChoiceChk2 == true && sTotal < 30)
            {
                Console.WriteLine("\t\t\t\tDelivery\t" + "$" + 5);
                Console.WriteLine("\t\t\t\tTip\t\t" + "$" + info.tip2);
                fTotal = sTotal + tax + 5 + info.tip2;
            }
            else
            {
                fTotal = sTotal + tax;
            }

            //Final Total
            Console.WriteLine("\t\t\t\t\t\t__________");
            Console.WriteLine("\t\t\t\tTotal\t\t" + "$" + "{0:0.00}", fTotal);

            writer.Close();

            string line;
            StreamReader reader;

            reader = new StreamReader("Receipt.txt");

            while (reader.EndOfStream == false)
            {
                line = reader.ReadLine();
                Console.WriteLine (line);
            }
            Console.Write("Press Enter to Continue");
            Console.ReadLine();

            reader.Close();
        }
    }
}
