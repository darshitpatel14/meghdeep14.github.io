﻿using System;

//Author: Darshitkumar Patel
//Description: High Grade
//use: Structure, method, array

namespace high_grades___1200_pts_meghdeep14
{
    /*struct StudentInfo
    {
        public string firstName;
        public string lastName;
        public double grade;
    }*/

    class Program
    {
        public static void HighGrads()
        {
            string[] firstName, lastName;
            int[] grade;
            int i, max;

            firstName = new string[4] {"abc", "ghi", "mno", "stu"};
            lastName = new string[4] {"def", "jkl", "pqr", "vwx"};
            grade = new int[4] {45, 64, 53, 43};

            Console.WriteLine(firstName[0] + " " + lastName[0] + "  " + grade[0]);
            Console.WriteLine(firstName[1] + " " + lastName[1] + "  " + grade[1]);
            Console.WriteLine(firstName[2] + " " + lastName[2] + "  " + grade[2]);
            Console.WriteLine(firstName[3] + " " + lastName[3] + "  " + grade[3]);

            max = grade[3];
            for(i=1; i<4; i++)
            {
                if(grade[i]>max)
                {
                    max = grade[i];
                }

            }
            Console.Write("Highest grade is {0}", max);
        }
        static void Main(string[] args)
        {
            HighGrads();
        }
    }
}
